# import unittest
# from unittest.mock import patch, mock_open

# from src.fileproc import manipulate  # Replace with the actual module name


# class TestManipulate(unittest.TestCase):
#     @patch('os.path.isdir')
#     @patch('os.listdir')
#     @patch('os.path.isfile')
#     @patch('builtins.open', new_callable=mock_open)
#     def test_mergecsvfiles(self, mock_open, mock_isfile, mock_listdir, mock_isdir):
#         mock_isdir.return_value = True
#         mock_listdir.return_value = ['file1.csv', 'file2.csv']
#         mock_isfile.side_effect = lambda x: x in ['merge_dir/file1.csv', 'merge_dir/file2.csv']

#         # simulating file contents
#         mock_open.side_effect = [
#             mock_open(read_data='header1,header2\ndata1,data2\n').return_value,
#             mock_open(read_data='header1,header2\ndata3,data4\n').return_value,
#             mock_open().return_value
#         ]

#         manipulator = manipulate()
#         merged_file = manipulator.mergecsvfiles(
#             merge_dir='merge_dir',
#             merge_wildcard='*.csv',
#             merge_name='merged.csv',
#             header=True,
#             delim=','
#         )

#         self.assertEqual(merged_file, 'merge_dir/merged.csv')
#         mock_open.assert_any_call('merge_dir/file1.csv', mode='r', newline='\n')
#         mock_open.assert_any_call('merge_dir/file2.csv', mode='r', newline='\n')
#         mock_open.assert_any_call('merge_dir/merged.csv', mode='w', newline='')

#     # @patch('os.path.isdir')
#     # @patch('os.listdir')
#     # @patch('shutil.copy2')
#     # def test_wildcardcopy(self, mock_copy2, mock_listdir, mock_isdir):
#     #     # Mocking os methods
#     #     mock_isdir.side_effect = [True, True]  # Both source and destination directories exist
#     #     mock_listdir.return_value = ['file1.txt', 'file2.log', 'file3.txt']

#     #     # Initialize manipulate instance
#     #     manipulator = manipulate()

#     #     # Call method under test
#     #     copied_files = manipulator.wildcardcopy(
#     #         source_dir='source_dir',
#     #         dest_dir='dest_dir',
#     #         file_wildcard='*.txt'
#     #     )

#     #     # Assert expected behavior
#     #     self.assertEqual(
#     #         copied_files,
#     #         ['dest_dir/file1.txt', 'dest_dir/file3.txt']
#     #     )
#     #     mock_copy2.assert_any_call('source_dir/file1.txt', 'dest_dir/file1.txt')
#     #     mock_copy2.assert_any_call('source_dir/file3.txt', 'dest_dir/file3.txt')

#     # @patch('os.path.isdir')
#     # def test_mergecsvfiles_invalid_directory(self, mock_isdir):
#     #     mock_isdir.return_value = False  # Directory does not exist

#     #     manipulator = manipulate()
#     #     with self.assertRaises(FileNotFoundError):
#     #         manipulator.mergecsvfiles(
#     #             merge_dir='invalid_dir',
#     #             merge_wildcard='*.csv',
#     #             merge_name='merged.csv'
#     #         )

#     # @patch('os.path.isdir')
#     # def test_wildcardcopy_invalid_directories(self, mock_isdir):
#     #     mock_isdir.side_effect = [False, True]  # Source does not exist, destination does

#     #     manipulator = manipulate()
#     #     with self.assertRaises(FileNotFoundError):
#     #         manipulator.wildcardcopy(
#     #             source_dir='invalid_dir',
#     #             dest_dir='dest_dir',
#     #             file_wildcard='*.txt'
#     #         )


# if __name__ == '__main__':
#     unittest.main()
